var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var ObjectID = Schema.Types.ObjectId;

var postSchema = new Schema(
	{
		authorID: {	type: ObjectID,required: true},
		content: { type: String, required: true},
		timestamp: { type: Date, required: true},
		comments: {
			type: [ObjectID]
		}
	},
	{
		collection: 'post'
	}
);

module.exports = mongoose.model('Post', postSchema);